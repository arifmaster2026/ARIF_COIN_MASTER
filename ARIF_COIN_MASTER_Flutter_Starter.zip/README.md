# ARIF COIN MASTER — Flutter starter

This is a starter source project for an Android/iOS app prototype with a black-and-gold theme.

## Included
- Home screen and coin balance
- Demo daily bonus and lucky spin
- Demo mini-game coin collection
- Rewards catalogue and demo redemption
- Basic local admin demo screen

## Important limitations
- Coin balance and rewards are stored only in app memory; they reset when the app restarts.
- The admin screen is NOT secure and is only a local prototype.
- No user accounts, cloud database, payment provider, cash withdrawal, fraud prevention, or production backend is included.
- Do not collect deposits or promise cash payouts with this prototype.

## Build requirements
Install Flutter SDK and Android Studio for Android builds. For iOS builds, a Mac with Xcode is required.

From this folder:
1. `flutter pub get`
2. Android: `flutter build apk --release`
3. iOS: `flutter build ipa --release` (on macOS with Xcode and Apple signing configured)

Before publishing, add secure authentication, a server-authoritative wallet/ledger, database, admin roles, privacy policy, terms, age/risk controls, and a compliant payment provider. Never put admin passwords or secret API keys in the app source.
