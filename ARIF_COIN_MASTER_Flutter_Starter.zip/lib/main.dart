import 'package:flutter/material.dart';

void main() => runApp(const ArifCoinMasterApp());

const gold = Color(0xFFE7BE62);
const panel = Color(0xFF1D1D1D);

class ArifCoinMasterApp extends StatelessWidget {
  const ArifCoinMasterApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ARIF COIN MASTER',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF101010),
        colorScheme: ColorScheme.fromSeed(
          seedColor: gold, brightness: Brightness.dark,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF101010), foregroundColor: gold,
        ),
        cardTheme: const CardTheme(
          color: panel, margin: EdgeInsets.symmetric(vertical: 7),
        ),
        useMaterial3: true,
      ),
      home: const HomeScreen(),
    );
  }
}

class Reward {
  Reward(this.name, this.cost);
  String name;
  int cost;
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int coins = 500;
  int tab = 0;
  bool dailyClaimed = false;
  bool spun = false;
  String notice = 'Welcome! Start earning coins.';
  final List<Reward> rewards = [
    Reward('Bronze Gift', 200),
    Reward('Silver Gift', 500),
    Reward('Gold Gift', 1000),
  ];
  final List<String> tasks = [
    'Play a game', 'Visit rewards store', 'Complete your profile',
  ];
  final Set<int> completed = {};

  void addCoins(int amount, String message) {
    setState(() {
      coins += amount;
      notice = message;
    });
  }

  void redeem(Reward reward) {
    if (coins < reward.cost) {
      setState(() => notice = 'Not enough coins for this reward.');
      return;
    }
    setState(() {
      coins -= reward.cost;
      notice = '${reward.name} redemption requested (demo only).';
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _home(),
      _games(),
      _rewards(),
      _admin(),
    ];
    return Scaffold(
      appBar: AppBar(
        title: const Text('👑 ARIF COIN MASTER',
          style: TextStyle(fontWeight: FontWeight.bold)),
        actions: [
          IconButton(
            tooltip: 'Profile',
            onPressed: () => setState(() => tab = 3),
            icon: const Icon(Icons.person_outline),
          )
        ],
      ),
      body: SafeArea(
        child: Column(children: [
          _balanceCard(),
          Expanded(child: IndexedStack(index: tab, children: pages)),
          Container(
            width: double.infinity,
            margin: const EdgeInsets.fromLTRB(14, 4, 14, 10),
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFF302719),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Text(notice,
              textAlign: TextAlign.center,
              style: const TextStyle(color: gold)),
          ),
        ]),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (value) => setState(() => tab = value),
        backgroundColor: const Color(0xFF191919),
        indicatorColor: const Color(0xFF59451F),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.videogame_asset_outlined), label: 'Games'),
          NavigationDestination(icon: Icon(Icons.card_giftcard), label: 'Rewards'),
          NavigationDestination(icon: Icon(Icons.admin_panel_settings_outlined), label: 'Admin'),
        ],
      ),
    );
  }

  Widget _balanceCard() => Container(
    width: double.infinity,
    margin: const EdgeInsets.fromLTRB(14, 4, 14, 8),
    padding: const EdgeInsets.all(18),
    decoration: BoxDecoration(
      gradient: const LinearGradient(
        colors: [Color(0xFF4A3919), Color(0xFF211B10)],
      ),
      borderRadius: BorderRadius.circular(18),
      border: Border.all(color: gold.withOpacity(.55)),
    ),
    child: Column(children: [
      const Text('YOUR COIN BALANCE',
        style: TextStyle(color: gold, letterSpacing: 1.3)),
      const SizedBox(height: 5),
      Text('$coins  🪙',
        style: const TextStyle(fontSize: 30, fontWeight: FontWeight.bold,
          color: Color(0xFFFFD978))),
      const Text('PLAY  •  EARN  •  REDEEM',
        style: TextStyle(color: Colors.white70, fontSize: 11)),
    ]),
  );

  Widget _section(String title, List<Widget> children) => ListView(
    padding: const EdgeInsets.fromLTRB(14, 0, 14, 12),
    children: [
      Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Text(title, style: const TextStyle(
          color: gold, fontSize: 20, fontWeight: FontWeight.bold)),
      ),
      ...children,
    ],
  );

  Widget _home() => _section('Welcome to the Game', [
    Card(child: ListTile(
      leading: const Icon(Icons.calendar_today, color: gold),
      title: const Text('Daily Bonus'),
      subtitle: const Text('Claim 100 coins once in this demo session.'),
      trailing: FilledButton(
        onPressed: dailyClaimed ? null : () {
          setState(() { dailyClaimed = true; coins += 100;
            notice = '100 daily bonus coins added!'; });
        },
        child: Text(dailyClaimed ? 'Claimed' : '+100'),
      ),
    )),
    Card(child: ListTile(
      leading: const Icon(Icons.casino, color: gold),
      title: const Text('Lucky Spin'),
      subtitle: const Text('One demo spin for 50 coins.'),
      trailing: FilledButton(
        onPressed: spun ? null : () {
          setState(() { spun = true; coins += 50;
            notice = 'Congratulations! You won 50 coins.'; });
        },
        child: Text(spun ? 'Done' : 'Spin'),
      ),
    )),
    const Padding(
      padding: EdgeInsets.only(top: 12, bottom: 4),
      child: Text('Daily Tasks', style: TextStyle(
        color: gold, fontWeight: FontWeight.bold, fontSize: 17)),
    ),
    ...List.generate(tasks.length, (i) => Card(
      child: CheckboxListTile(
        activeColor: gold,
        value: completed.contains(i),
        title: Text(tasks[i]),
        subtitle: Text('+${i == 0 ? 50 : 25} coins'),
        onChanged: (value) {
          setState(() {
            if (value == true && completed.add(i)) {
              coins += i == 0 ? 50 : 25;
              notice = 'Task completed. Coins added.';
            } else if (value == false && completed.remove(i)) {
              coins -= i == 0 ? 50 : 25;
            }
          });
        },
      ),
    )),
  ]);

  Widget _games() => _section('Mini Games', [
    Card(child: Padding(
      padding: const EdgeInsets.all(16),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Icon(Icons.monetization_on, color: gold, size: 42),
        const SizedBox(height: 8),
        const Text('Coin Catcher',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const Text('Tap the button to collect demo coins.'),
        const SizedBox(height: 12),
        SizedBox(width: double.infinity, child: FilledButton(
          onPressed: () => addCoins(10, 'You collected 10 coins!'),
          child: const Text('Collect 10 Coins'),
        )),
      ]),
    )),
    const Card(child: ListTile(
      leading: Icon(Icons.extension, color: gold),
      title: Text('More games coming soon'),
      subtitle: Text('Admin can add game entries after backend setup.'),
    )),
  ]);

  Widget _rewards() => _section('Rewards Store', [
    ...rewards.map((reward) => Card(child: ListTile(
      leading: const Icon(Icons.card_giftcard, color: gold, size: 30),
      title: Text(reward.name),
      subtitle: Text('${reward.cost} coins'),
      trailing: FilledButton(
        onPressed: coins >= reward.cost ? () => redeem(reward) : null,
        child: const Text('Redeem'),
      ),
    ))),
    const Card(child: Padding(
      padding: EdgeInsets.all(14),
      child: Text(
        'Cash redemption is not connected. A real-money payout system needs '
        'a verified payment provider, server-side fraud checks, legal review, '
        'and clear eligibility rules.',
      ),
    )),
  ]);

  Widget _admin() => _section('Admin Panel • Demo', [
    const Card(child: Padding(
      padding: EdgeInsets.all(14),
      child: Text(
        'This is a local prototype admin screen. It is not protected by '
        'server authentication and must not be used to manage real users or money.',
      ),
    )),
    Card(child: ListTile(
      leading: const Icon(Icons.add_circle, color: gold),
      title: const Text('Add 100 test coins'),
      subtitle: const Text('For testing the balance only'),
      trailing: IconButton(
        icon: const Icon(Icons.add, color: gold),
        onPressed: () => addCoins(100, 'Admin demo: 100 test coins added.'),
      ),
    )),
    Card(child: ListTile(
      leading: const Icon(Icons.add_box, color: gold),
      title: const Text('Add a sample reward'),
      subtitle: const Text('Adds a reward to this device only'),
      trailing: IconButton(
        icon: const Icon(Icons.add, color: gold),
        onPressed: () => setState(() {
          rewards.add(Reward('New Custom Gift', 750));
          notice = 'Sample reward added.';
        }),
      ),
    )),
    const Card(child: ListTile(
      leading: Icon(Icons.security, color: gold),
      title: Text('Secure admin login'),
      subtitle: Text('Must be implemented on a backend before launch.'),
    )),
  ]);
}
